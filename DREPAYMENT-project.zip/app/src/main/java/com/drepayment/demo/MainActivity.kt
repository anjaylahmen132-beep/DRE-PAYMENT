package com.drepayment.demo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private var saldo = 100000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun base(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(28,28,28,28)
        l.setBackgroundColor(Color.rgb(247,248,252))
        return l
    }

    private fun tv(text:String, size:Float=16f, bold:Boolean=false): TextView {
        val t=TextView(this); t.text=text; t.textSize=size; t.setTextColor(Color.rgb(25,27,35))
        if(bold) t.setTypeface(null,1); t.setPadding(0,10,0,10); return t
    }

    private fun btn(text:String, action:()->Unit): Button {
        val b=Button(this); b.text=text; b.setOnClickListener{action()}; return b
    }

    private fun showLogin() {
        val l=base(); l.gravity=Gravity.CENTER
        l.addView(tv("DREPAYMENT",30f,true))
        l.addView(tv("Aplikasi PPOB Demo",16f))
        val phone=EditText(this); phone.hint="Nomor HP"
        l.addView(phone)
        val pass=EditText(this); pass.hint="Password"; pass.inputType=129
        l.addView(pass)
        l.addView(btn("MASUK"){ showHome() })
        l.addView(tv("Demo • Tanpa KTP • Tanpa transaksi uang asli",12f))
        setContentView(l)
    }

    private fun showHome() {
        val l=base()
        l.addView(tv("DREPAYMENT",28f,true))
        l.addView(tv("Halo, Pengguna 👋",18f,true))
        val card=TextView(this); card.text="SALDO DEMO\nRp ${"%,d".format(saldo).replace(',','.')}"
        card.textSize=22f; card.setTextColor(Color.WHITE); card.setPadding(24,24,24,24)
        card.setBackgroundColor(Color.rgb(70,74,190)); l.addView(card)
        l.addView(btn("💰 Deposit Demo"){ saldo+=50000; showHome() })
        l.addView(btn("📱 Pulsa & Paket Data"){ showProducts("Pulsa & Paket Data") })
        l.addView(btn("⚡ Token PLN"){ showProducts("Token PLN") })
        l.addView(btn("🎮 Voucher Game"){ showProducts("Voucher Game") })
        l.addView(btn("💳 E-Wallet"){ showProducts("E-Wallet") })
        l.addView(btn("📷 QR Pembayaran Demo"){ 
            Toast.makeText(this,"QR demo dibuat — tidak dapat menerima uang asli.",Toast.LENGTH_LONG).show()
        })
        l.addView(btn("🧾 Riwayat Transaksi"){ 
            Toast.makeText(this,"Belum ada transaksi nyata. Ini mode demo.",Toast.LENGTH_LONG).show()
        })
        l.addView(btn("⚙️ Profil"){ showProfile() })
        setContentView(l)
    }

    private fun showProducts(title:String) {
        val l=base(); l.addView(tv(title,26f,true))
        val items=listOf("Produk Demo 1 — Rp10.000","Produk Demo 2 — Rp25.000","Produk Demo 3 — Rp50.000")
        for (item in items) l.addView(btn(item){
            Toast.makeText(this,"Transaksi simulasi berhasil.",Toast.LENGTH_SHORT).show()
            showHome()
        })
        l.addView(btn("← Kembali"){showHome()}); setContentView(l)
    }

    private fun showProfile() {
        val l=base(); l.addView(tv("Profil",26f,true))
        l.addView(tv("Nama: Pengguna Demo"))
        l.addView(tv("Nomor HP: tersimpan lokal"))
        l.addView(tv("KTP: tidak diperlukan untuk demo"))
        l.addView(btn("← Kembali"){showHome()}); setContentView(l)
    }
}
