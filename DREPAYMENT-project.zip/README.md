# DREPAYMENT
Demo aplikasi PPOB Android. Saldo, deposit, QR, dan transaksi bersifat simulasi.

## Build dari HP
1. Ekstrak ZIP ini.
2. Gunakan Android Studio/IDE Android yang mendukung Gradle.
3. Buka folder proyek dan tunggu Gradle sync.
4. Jalankan `assembleDebug`.
5. APK berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: versi ini tidak memproses uang asli dan tidak melakukan KYC.
